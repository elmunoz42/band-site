# These files are used to build the Pushtape distribution on Drupal.org or from scratch using Drush.

## Download the packaged distribution as a tarball from Drupal.org
http://www.drupal.org/project/pushtape

## Build pushtape from scratch using drush make: http://drush.ws/#make

To manually build the Pushtape distribution in the current directory, in the terminal type:
    
    drush make build-pushtape.make

To install the distribution:

    drush site-install pushtape





